// another after the slashes does not execute
var year = 2012,
  month = "October", // this is the month
  // day = 31,
  holiday = "Halloween";

/*
You can write comments
across multiple lines
finally ending with:
*/

var tinyAlmanac = {
  year: 2012,
  month: "October",
  day: 31,
  holiday: "Halloween"
};

// watch out for block comments here
var myRegExp = /[0-9].*/;

// More info:
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Lexical_grammar#comments
