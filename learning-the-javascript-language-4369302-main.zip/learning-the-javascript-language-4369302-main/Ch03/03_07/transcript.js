var year=2012,month='October',day=31,holiday='Halloween';

var year   = 2012,       month    =    'October', day =          31,          holiday='Halloween';

var year = 2012,
	month = 'October',
	day = 31,
	holiday = 'Halloween';
	
var year  = 2012,
	month   = 'October',
	day     = 31,
	holiday = 'Halloween';

var tinyAlmanac={'year':2012,'month':'October','day':31,'holiday':'Halloween'};

var tinyAlmanac = {
	'year' : 2012,
	'month' : 'October',
	'day' : 31,
	'holiday' : 'Halloween'
};

var longString = "Four score \
and seven years ago \
our fathers brought forth \
on this continent \
a new nation";

// More info:
// These are not specifications on whitespace, but the Mozilla code style guide discusses formatting.
// https://developer.mozilla.org/en-US/docs/MDN/Writing_guidelines/Writing_style_guide/Code_style_guide/JavaScript#choosing_a_format
